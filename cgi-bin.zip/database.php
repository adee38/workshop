<?php
$user = "root";
$host = "localhost";
$pass = "";
$database = "mech";
?>
