#!/usr/bin/perl
# hello.pl -- my first perl script CryBit.com!

print "Content-type: text/html\n\n";
print "Hello, world!\n";
