		<div class="content">
			<img src="images/404.png">
		</div>
