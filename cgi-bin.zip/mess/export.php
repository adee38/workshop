<?php

include "database.php";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

if(isset($_GET['mess'])){
	$mess = $_GET['mess'];

	$sql = "SELECT * FROM `students` WHERE `Mess` = ".$mess;
	$result = $conn->query($sql);
	if (!$result) die('Couldn\'t fetch records');
	$headers = $result->fetch_fields();
	foreach($headers as $header) {
		$head[] = $header->name;
	}
	$fp = fopen('php://output', 'w');

	if ($fp && $result) {
		header('Content-Type: text/csv');
		header('Content-Disposition: attachment; filename="Mess '.$mess.'.csv"');
		header('Pragma: no-cache');
		header('Expires: 0');
		//fputcsv($fp, array_values($head)); 
		while ($row = $result->fetch_array(MYSQLI_NUM)) {
			fputcsv($fp, array_values($row));
		}
		die;
	}
}
else{
	$sql = "SELECT * FROM `students`";
	$result = $conn->query($sql);
	if (!$result) die('Couldn\'t fetch records');
	$headers = $result->fetch_fields();
	foreach($headers as $header) {
		$head[] = $header->name;
	}
	$fp = fopen('php://output', 'w');

	if ($fp && $result) {
		header('Content-Type: text/csv');
		header('Content-Disposition: attachment; filename="Mess_all.csv"');
		header('Pragma: no-cache');
		header('Expires: 0');
		//fputcsv($fp, array_values($head)); 
		while ($row = $result->fetch_array(MYSQLI_NUM)) {
			fputcsv($fp, array_values($row));
		}
		die;
	}
}
?>
