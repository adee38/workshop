<?php

include "database.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

$userinfo = array(
	'admin'=>'iambatman007'
);

if(isset($_GET['logout'])) {
	$_SESSION['username'] = '';
	header('Location:  ' . $_SERVER['PHP_SELF']);
}

if(isset($_POST['username'])) {
	if(isset($userinfo[$_POST['username']])&&($userinfo[$_POST['username']] == $_POST['password'])) {
		$_SESSION['username'] = $_POST['username'];
	}else {
		echo "Incorrect Credentials";
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="SHORTCUT ICON" href="../favicon.ico" />
<title>Administration</title>
<link rel="stylesheet" href="admin-style.css">

</head>
<body>

<?php if(isset($_SESSION['username']) && $_SESSION['username']){
?>
	<div class="topbar">
		<a class="right" href="?logout">Logout</a>
		<a class="right" href="?email">Email</a>
		<a class="right" href="?allocation">Allocation</a>
		<a class="right" href="?feedback">Feedback</a>
		<a href="admin.php">Admin Panel</a>
	</div>

<?php

	if(isset($_GET['email'])) {
		$sql = "SELECT COUNT(*) from `students` WHERE `Mess` = 0";
		$result = $conn->query($sql);
		$row = mysqli_fetch_assoc($result);
		$total = $row['COUNT(*)'];
		?>
		Total: <?php echo $total?><br><br>

		Send email to: <br>
		<?php
		$i_max = (int) ($total/500 + 1);
		for($i=0;$i<$i_max;$i++){
			$low = $i*500;
			$up = $i*500 + 499;
			echo "<a href='massmail.php?low=".$low."&up=".$up."'>".$low." to ".$up."</a><br>";
		}
		?>
		<br><br>
		The list of students who haven't filled in their choices:<br><br>
		<table>
		<?php
		$sql = "SELECT * from `students` WHERE `Mess` = 0";
		$result = $conn->query($sql);
		while($row = mysqli_fetch_object($result)){
			?>
			<tr><td><?php echo $row->{'Name'} ?></td><td><?php echo $row->{'Roll No'} ?></td><td><?php echo $row->{'email'} ?></td><td><a href="mail.php?roll=<?php echo $row->{'Roll No'} ?>">Send Mail</a></td></tr>
			<?php
		}

		?>
		</table>
		<?php
	}
	else if(isset($_GET['allocation'])){
		?>
		Download: <a href="export.php?mess=1">Mess 1</a> | <a href="export.php?mess=2">Mess 2</a> | <a href="export.php">All</a> | <a href="export.php?mess=0">Unallocated</a><br><br>
		<table>
		<?php
		$sql = "SELECT * from `students`";
		$result = $conn->query($sql);
		while($row = mysqli_fetch_object($result)){
			?>
			<tr><td><?php echo $row->{'Name'} ?></td><td><?php echo $row->{'Roll No'} ?></td><td><?php echo $row->{'email'} ?></td><td>Mess <?php echo $row->{'Mess'} ?></td><td><a href="mail.php?roll=<?php echo $row->{'Roll No'} ?>">Send Mail</a></td></tr>
			<?php
		}
		?>
		</table>

		<br><br><a href="unallocate.php">Unallocate everyone</a> | <a href="delete.php">Delete All</a> | <a href="import.php">Import</a> | <a href="generate_qr.php">Generate QR</a><br><br>
		<?php
	}
	else if(isset($_GET['feedback'])){
		?>

		<table>
		<?php
		$sql = "SELECT * from `rating`";
		$result = $conn->query($sql);
		while($row = mysqli_fetch_object($result)){
			?>
			<tr><td><?php echo $row->{'Roll No'} ?></td><td><?php echo $row->{'Rating'} ?></td><td><?php echo $row->{'Comment'} ?></td><td><?php echo $row->{'Time'} ?></td></tr>
			<?php
		}
		?>
		</table>
		<?php
	}
	else{
		echo "Welcome to the admin panel. Proceed with caution.";
	}

?>

<?php }
else {
?>


<div class="box" style="text-align:center;">
	<br>
	<form name="login" action="" method="post">
		<input id="form" type="text" name="username" value="Username" onblur="if (this.value == '') {this.value = 'Username';}" onfocus="if (this.value == 'Username') {this.value = '';}"><br>
		<input id="form" type="password" name="password" value="password" onblur="if (this.value == '') {this.value = 'password';}" onfocus="if (this.value == 'password') {this.value = '';}"><br><br>
		<input id="login" type="submit" name="submit" value="Submit">
	</form>
	<p><br><br>Administration Panel</p>
</div>


<?php }
?>
</body>
</html>
