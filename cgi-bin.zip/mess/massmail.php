<?php

include "database.php";

if(isset($_GET['up']) && isset($_GET['low'])) {
	$up = $_GET['up'];
	$low = $_GET['low'];
	$diff = $up - $low;
}
else{
	$up = 0;
	$low = 0;
	$diff = $up - $low;
}


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * from `students` LIMIT ".$low.", ".$diff;
$result = $conn->query($sql);

$message = "Please go to the following link to choose your mess and download your QR Code: ";
$headers = "From: mess@icscc.online" . "\r\n";

while($row = mysqli_fetch_object($result)){
	if(empty($row->{'email'})){
		continue;
	}
	if(strpos($row->{'email'}, '@') !== false){
		$email = $row->{'email'};
	}
	else{
		$email = $row->{'email'}."@iitp.ac.in";
	}
	$link = "http://mess.icscc.online/?enc=" . generate($row->{'Roll No'});
	echo $email."<br>";

	mail($email,"Mess - Choice and QR Code",$message.$link,$headers);
}

?>
