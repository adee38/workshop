<?php

include "database.php";

include "phpqrcode/qrlib.php";

$encryption_key = "BatMaN!007GurUjI";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * from `students`";
$result = $conn->query($sql);

while($row = mysqli_fetch_object($result)){
	QRcode::png($row->Name."\n".$row->{'Roll No'}."\n".generate($row->{'Roll No'}), "qr/".generate($row->{'Roll No'}).".png");
	echo 'Done: '.generate($row->{'Roll No'})."<br>";
}

?>
