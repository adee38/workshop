<?php

include("database.php");

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	 die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['submit'])) {

	if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
		$filename = $_FILES['filename']['tmp_name'];
		$file = fopen($filename, "r");
		while (($getData = fgetcsv($file, 10000, ",")) !== FALSE) {
			$sql = "INSERT into `students` (Name,`Roll No`,email,Mess,marked) 
					 values ('".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."')";
					 $result = $conn->query($sql);
			if(!isset($result)) {
				echo "<script type=\"text/javascript\">
						alert(\"Invalid File:Please Upload CSV File.\");
						window.location = \"admin.php?allocation\"
					  </script>";		
			}
			else {
				  echo "<script type=\"text/javascript\">
					alert(\"CSV File has been successfully Imported.\");
					window.location = \"admin.php?allocation\"
				</script>";
			}
		 }		
		fclose($file);	
	}
	else{
		echo "please post a file into this...";
	}
}
else{
	?>
		Please uplaod the CSV file:<br><br>
		<form enctype='multipart/form-data' action='import.php' method='post'>
			<input size='50' type='file' name='filename'> 
			<input type='submit' name='submit' value='Upload'>
		</form>
	<?php
}
?>
