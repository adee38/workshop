<?php

$servername = "localhost";
$username = "mess";
$password = "y5JynDq@%oq=";
$dbname = "mess";

$encryption_key = "BatMaN!007GurUjI";

function generate($roll_number){
	return md5($roll_number.$GLOBALS['encryption_key']);
}

?>
