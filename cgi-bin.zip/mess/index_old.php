<html>
<head>
<title>IIT Patna - Mess</title>
<style>

html, body, div, span, applet, object, iframe,
h1, h2, h3, h4, h5, h6, p, blockquote, pre,
a, abbr, acronym, address, big, cite, code,
del, dfn, em, img, ins, kbd, q, s, samp,
small, strike, strong, sub, sup, tt, var,
b, u, i, center,
dl, dt, dd, ol, ul, li,
fieldset, form, label, legend,
table, caption, tbody, tfoot, thead, tr, th, td,
article, aside, canvas, details, embed, 
figure, figcaption, footer, header, hgroup, 
menu, nav, output, ruby, section, summary,
time, mark, audio, video {
	margin: 0;
	padding: 0;
	border: 0;
	font-size: 100%;
	font: inherit;
	vertical-align: baseline;
}
/* HTML5 display-role reset for older browsers */
article, aside, details, figcaption, figure, 
footer, header, hgroup, menu, nav, section {
	display: block;
}
body {
	line-height: 1;
	height:100%;
}
ol, ul {
	list-style: none;
}
blockquote, q {
	quotes: none;
}
blockquote:before, blockquote:after,
q:before, q:after {
	content: '';
	content: none;
}
table {
	border-collapse: collapse;
	border-spacing: 0;
}

body {
	text-align: center;
}

h2 {
	font-size: 2em;
	font-weight: 700;
	margin: 0.5em;
}

h3 {
	font-size: 1.5em;
	font-weight: 700;
	margin: 0.25em;
}

form {
	font-size: 2.5em;
}
input {
	font-size: 1em;
}

img {
	width: 20em;
	height: 20em;
}
</style>
</head>
<body>
<?php

include "database.php";

//include "phpqrcode/qrlib.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function enc_search($encrypted){
	$encr_key = $GLOBALS['encryption_key'];
	//$sql = "SELECT * FROM `students` WHERE MD5(CONCAT(`Roll No`,`$encr_key`)) = `$encrypted`"; #for some reason this is not working...
	$sql = "SELECT * FROM `students` WHERE MD5(CONCAT(`Roll No`,'".$encr_key."')) = '".$encrypted."'";
	$result = $GLOBALS['conn']->query($sql);
	$row = mysqli_fetch_object($result);
	//$json = json_encode($row, JSON_PRETTY_PRINT);
	//echo $json;
	return $row;
}

function choice($qrcode){
	$row = enc_search($qrcode);
	if(empty($row)){
		$error = new \stdClass();
		$error->error = "Person doesn't exist in our database";
		echo json_encode($error, JSON_PRETTY_PRINT);
	}
	else{
		$sql = "SELECT COUNT(`Mess`) FROM `students` WHERE `Mess` = 1";
		$resultz = $GLOBALS['conn']->query($sql);
		$rowz = mysqli_fetch_array($resultz);
		$mess1 = $rowz[0];

		$sql = "SELECT COUNT(`Mess`) FROM `students` WHERE `Mess` = 2";
		$resultz = $GLOBALS['conn']->query($sql);
		$rowz = mysqli_fetch_array($resultz);
		$mess2 = $rowz[0];

		//QRcode::png($row->Name."\n".$row->{'Roll No'}."\n".generate($row->{'Roll No'}), "qr/".$qrcode.".png");
		?>
		<h2>Hello, <?php echo $row->Name; ?>.</h2>

		<?php
		if($row->Mess == 0){
		?>
		<p>You haven't chosen a mess yet. Please submit the following form.</p>
		<?php
		}
		else {
		?>

		<p>Your current choice of mess is Mess <?php echo $row->Mess ?>. Please submit the following form if you wish to make a change.</p>

		<?php
		}
		?>

		<h3>Choose a mess</h3>

		<form name="choice" action="" method="post">
			<?php if($mess1<780){?>
				<input type="radio" name="mess" value="1"> Mess 1<br>
			<?php } if($mess2<780){?>
				<input type="radio" name="mess" value="2"> Mess 2<br>
			<?php } ?>
			<input type="hidden" name="enc" value="<?php echo $qrcode ?>">
			<input type="submit" value="submit">

		</form>
		<br><br>
		Note that the max. capacity of each mess is 780. Currently, the number of people who have opted for Mess 1 is <?php echo $mess1 ?> and for Mess 2 is <?php echo $mess2 ?>.

		<br><br>
		<h3>QR Code:</h3>
		Please keep the following QR code with you while going into the mess.<br><br>
		<?php
		echo '<img src="qr/'.$qrcode.'.png" />';
	}
}

if(isset($_POST['mess'])) {
	$mess = $_POST['mess'];
	$encrypted = $_POST['enc'];
	
	$sql = "UPDATE `students` SET Mess = $mess WHERE MD5(CONCAT(`Roll No`,'".$encryption_key."')) = '".$encrypted."'";
	$result = $GLOBALS['conn']->query($sql);
	if($result){
		echo "Succesfully updated your preference.";
	}
	else{
		echo "Sorry, something went wrong. Contact the admin.";
	}
}
else if(isset($_GET["enc"])){
	choice($_GET["enc"]);
}
else{
	echo "You might have landed in this page by mistake...";
}

?>
</body>
</html>
