<?php
//TRUNCATE students
include "database.php";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
$sql = "TRUNCATE `students`";
$result = $conn->query($sql);

echo $result;

header("Location: admin.php?allocation");
?>
