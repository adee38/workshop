<?php

include "database.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT * FROM `students`";
$result = $conn->query($sql);
while($row = mysqli_fetch_object($result)){
	$sqlz = "UPDATE `students` SET `Mess` = '0'";
	$resultz = $conn->query($sqlz);
}

echo "Unallocating everyone...";
?>
